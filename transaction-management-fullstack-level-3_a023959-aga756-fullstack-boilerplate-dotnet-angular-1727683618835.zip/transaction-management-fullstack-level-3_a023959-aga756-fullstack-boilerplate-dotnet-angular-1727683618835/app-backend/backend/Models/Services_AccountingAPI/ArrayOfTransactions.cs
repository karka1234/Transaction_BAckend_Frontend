using System.Collections.Generic;
using Newtonsoft.Json;

namespace backend.Models.Services_AccountingAPI;

public class ArrayOfTransactions
{
    [JsonProperty("transactions")]
    public List<Transaction> Transactions { get; set;}
    public ArrayOfTransactions() {}
    public ArrayOfTransactions(List<Transaction> transactions)
    {
        Transactions = transactions;
    }
}
